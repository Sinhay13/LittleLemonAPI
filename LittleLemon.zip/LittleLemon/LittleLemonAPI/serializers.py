from rest_framework import serializers
from django.contrib.auth.models import User
from .models import Category, MenuItem, Cart, Order, OrderItem

#Category: 
class CategorySerializer(serializers.ModelSerializer):
    class Meta:
        model = Category
        fields = ['id', 'slug', 'title']
#________________________________________________________________#

#Menu-Items:
class MenuItemSerializer(serializers.ModelSerializer):
    category=CategorySerializer(read_only=True)
    category_id=serializers.SlugField(write_only=True)
    class Meta:
        model = MenuItem
        fields = ['id', 'title', 'price', 'featured', 'category', "category_id"]

#_____________________________________________________________________#

# for users management: 
from django.contrib.auth.models import User

class UserSerializer(serializers.ModelSerializer):
    class Meta:
        model = User
        fields = ['id', 'username', 'email']


# Cart :

class CartSerializer(serializers.ModelSerializer):
    menuitem = serializers.PrimaryKeyRelatedField(queryset=MenuItem.objects.all())
    quantity = serializers.IntegerField(min_value=1, max_value=100)
    unit_price = serializers.DecimalField(max_digits=6, decimal_places=2, read_only=True)
    price = serializers.DecimalField(max_digits=6, decimal_places=2, read_only=True)
    menuitem_name = serializers.SerializerMethodField()

    class Meta:
        model = Cart
        fields = ('id', 'menuitem', 'menuitem_name', 'quantity', 'unit_price', 'price')

    def get_menuitem_name(self, obj):
        return obj.menuitem.title

    def validate(self, data):
        menuitem = data['menuitem']
        quantity = data['quantity']
        data['unit_price'] = menuitem.price
        data['price'] = menuitem.price * quantity
        return data




#______________________________________________________________________#

# Orders: 
class OrderItemSerializer(serializers.ModelSerializer):
    menuitem = MenuItemSerializer()

    class Meta:
        model = OrderItem
        fields = ['menuitem', 'quantity', 'unit_price', 'price']

class OrderDetailUserSerializer(serializers.ModelSerializer):
    orderitem_set = OrderItemSerializer(many=True)

    class Meta:
        model = Order
        fields = ['id', 'status', 'total', 'date', 'orderitem_set']


class OrderSerializer(serializers.ModelSerializer):
    user = serializers.ReadOnlyField(source='user.username')
    delivery_crew = serializers.ReadOnlyField(source='Delivery.username')

    class Meta:
        model = Order
        fields = ['id', 'user', 'delivery_crew', 'status', 'total', 'date']

class OrderItemCreateSerializer(serializers.Serializer):
    cart = serializers.ListField(child=serializers.DictField())

    def create(self, validated_data):
        user = self.context['request'].user
        order_items = validated_data['cart']
        total = 0
        for item in order_items:
            total += item['price']
        order_data = {
            'user': user.id,
            'total': total
        }
        order = Order.objects.create(**order_data)
        for item in order_items:
            menuitem_id = item['menuitem']
            quantity = item['quantity']
            unit_price = item['unit_price']
            price = item['price']
            OrderItem.objects.create(order=order, menuitem_id=menuitem_id, quantity=quantity, unit_price=unit_price, price=price)
        return order